import { Component } from '@angular/core';

@Component({
  selector: 'app-patients',
  imports: [],
  standalone: true,

  templateUrl: './patients.component.html',
  styleUrl: './patients.component.css'
})
export class PatientsComponent {

}

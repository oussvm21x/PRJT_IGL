import { Component } from '@angular/core';

@Component({
  selector: 'app-parametres',
  imports: [],
  standalone: true,
  templateUrl: './parametres.component.html',
  styleUrl: './parametres.component.css'
})
export class ParametresComponent {

}
